/** Automatically generated file. DO NOT MODIFY */
package vatsag.samples.smartphonestatus;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}