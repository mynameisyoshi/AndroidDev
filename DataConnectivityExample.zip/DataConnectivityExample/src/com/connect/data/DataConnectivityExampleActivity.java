package com.connect.data;


import com.sws901.data.R;

import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.telephony.PhoneStateListener;
import android.telephony.TelephonyManager;
import android.widget.TextView;

public class DataConnectivityExampleActivity extends Activity {
	private TextView telMgrOutput;
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        
        this.telMgrOutput = (TextView) this.findViewById(R.id.telmgroutput);
    }
    
    @Override
    public void onStart() {
    	super.onStart();
    	final StringBuilder sb = new StringBuilder();
    	try
    	{
    		// TelephonyManager
    		final TelephonyManager telMgr = (TelephonyManager) this.getSystemService(Context.TELEPHONY_SERVICE);
    		this.telMgrOutput.setText(telMgr.toString());
    		
    		sb.append("telMgr - ");  

    		
    		PhoneStateListener dataStateListener = new PhoneStateListener() {
    			public void onDataActivity(int direction) {
    				String activity = "NA";
    				switch (direction) {
    				case TelephonyManager.DATA_ACTIVITY_IN : 
    					activity = "DATA Acitivity in: ";
    					break;
    				case TelephonyManager.DATA_ACTIVITY_OUT : 
    					activity = "DATA Acitivity out: ";
    					break;
    				case TelephonyManager.DATA_ACTIVITY_INOUT : 
    					activity = "DATA Acitivity in out: ";
    					break;
    				case TelephonyManager.DATA_ACTIVITY_NONE : 
    					activity = "DATA Acitivity none: ";
    					break;
    				}
    				
    			      
    			      sb.append("  \nDataActivity = " + activity);
    			      telMgrOutput.setText(sb);

    			}
    			public void onDataConnectionStateChanged(int state) { 
    				String connectivity = "NA";
    				switch (state) {
    				case TelephonyManager.DATA_CONNECTED : 
    					connectivity = "data connected -";
    					break;
    				case TelephonyManager.DATA_CONNECTING : 
    					connectivity = "data connecting -";
    					break;
    				case TelephonyManager.DATA_DISCONNECTED : 
    					connectivity = "data disconnected -";
    					break;
    				case TelephonyManager.DATA_SUSPENDED : 
    					connectivity = "data suspended -";
    					break;
    				}
    				 sb.append("  \nConnectionState = " + connectivity);
    				 telMgrOutput.setText(sb);
    			}
    		};
    		telMgr.listen(dataStateListener,PhoneStateListener.LISTEN_DATA_ACTIVITY |PhoneStateListener.LISTEN_DATA_CONNECTION_STATE );
    		
   	      this.telMgrOutput.setText(sb);
    	}
    	catch(Exception ex){
    		System.out.println(ex.toString());
    		String x = "hello";
    	}
    }
}