/** Automatically generated file. DO NOT MODIFY */
package com.example.sensors;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}