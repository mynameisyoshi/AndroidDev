package com.example.gettingsimdetails;


import android.os.Bundle;
import android.app.Activity;
import android.content.Context;
import android.telephony.TelephonyManager;
import android.view.Menu;
import android.widget.TextView;

public class MainActivity extends Activity {
	private TextView telSIM;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		
		telSIM = (TextView) this.findViewById(R.id.telmgroutput);
		
		
	}

	 @Override
	    public void onStart() {
	    	super.onStart();
	    	final StringBuilder sb = new StringBuilder();
	    	// TelephonyManager
    		final TelephonyManager telMgr = (TelephonyManager) this.getSystemService(Context.TELEPHONY_SERVICE);
    		
	    	try
	    	{
	    		int simState = telMgr.getSimState();
	    		switch (simState) {
	    		case (TelephonyManager.SIM_STATE_ABSENT): 
	    			sb.append("SIM basent");
	    			break;
	    		case (TelephonyManager.SIM_STATE_NETWORK_LOCKED): 
	    			sb.append("SIM Network Locked");
	    			break;
	    		case (TelephonyManager.SIM_STATE_PIN_REQUIRED): 
	    			sb.append("SIM PIN Required");
	    			break;
	    		case (TelephonyManager.SIM_STATE_PUK_REQUIRED): 
	    			sb.append("SIM State PUK Required");
	    			break;
	    		case (TelephonyManager.SIM_STATE_UNKNOWN): 
	    			sb.append("SIM State Unkwon");
	    			break;
	    		case (TelephonyManager.SIM_STATE_READY): {
	    			 sb.append("  \nSIM Crountry = " + "SIM State Ready!");
		    		// Get the SIM country ISO code
		    		String simCountry = telMgr.getSimCountryIso();
		    		 sb.append("  \nSIM Crountry = " + simCountry);
		    		// Get the operator code of the active SIM (MCC + MNC)
		    		String simOperatorCode = telMgr.getSimOperator();
		    		sb.append("  \nOperator Code = " + simOperatorCode);
		    		// Get the name of the SIM operator
		    		String simOperatorName = telMgr.getSimOperatorName();
		    		sb.append("  \nOperator Name = " + simOperatorName);
		    		// -- Requires READ_PHONE_STATE uses-permission --
		    		// Get the SIM�s serial number
		    		String simSerial = telMgr.getSimSerialNumber();
		    		sb.append("  \nSIM Serial = " + simSerial);
		    		//IMSI
		    		String imsi = telMgr.getSubscriberId();
		    		sb.append("  \nSIM IMSI = " + imsi);
		    		}
	    		}
	    		this.telSIM.setText(sb.toString());
	    	}
	    	catch(Exception ex){
	    		System.out.println(ex.toString());
	    		String x = "hello";
	    	}
	   }
	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}

}
