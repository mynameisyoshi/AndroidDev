package com.cox.assign3;

import java.io.File;

import android.app.Activity;
import android.content.Intent;
import android.content.res.Resources;
import android.database.Cursor;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore.Video;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.MediaController;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.VideoView;

public class Michael_video extends Activity {

	Cursor mediaCursor=null;
	VideoView videoView=null;
	int video_index;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.video_cox1);
		
		Resources res = getResources();
		
		Button tv = (Button)findViewById(R.id.button1);
		tv.setText(getResources().getString(R.string.pause));
		
		play_video();
	}
	
	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.michael_video, menu);
		return true;
	}
	
	public void play_video()
	{
		videoView = (VideoView)findViewById(R.id.videoView1);
		try
		{
			Resources res = getResources();
			
			final TextView tv = (TextView)findViewById(R.id.textView2);
			tv.setText("");
			final String path =  Environment.getExternalStorageDirectory()+"/Videos/";
			
			File yourDir = new File(Environment.getExternalStorageDirectory(), "/Videos");
			
			String newpath = Environment.getExternalStorageDirectory()+"/Videos/Troll2.3gp";
			
			final File[] files = yourDir.listFiles();
			int count = 0;
			
			for(File file:files)
			{
				if(file.getName().toString().endsWith(".3gp"))
				{
					count ++;
				}
			}
			 final int pass_count = count;
			if(count == 0)
			{
				tv.setText(res.getString(R.string.name)+"  no 3gp files to play");
			}
			else
			{
					if(files[0].getName().toString().endsWith(".3gp"))
					{
					    Toast.makeText(Michael_video.this, ""+files[0].getName().toString(), Toast.LENGTH_SHORT).show();						
						tv.setText(files[0].getName().toString());
					    videoView.setVideoPath(path+files[0].getName().toString());
						videoView.setMediaController(new MediaController(this));
						videoView.requestFocus();
						videoView.start();
				
						videoView.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
	                         
						    int count = 0;
						    int counter = pass_count;
							@Override
							public void onCompletion(MediaPlayer arg0)
							{
							    	
							    count++;
								if(count < files.length)
								{
									if(files[count].getName().toString().endsWith(".3gp"))
									{
										tv.setText(files[count].getName().toString());
										videoView.setVideoPath(path+files[count].getName().toString());
										videoView.start();
								    }
								}
								else if(count > pass_count)
								{
									Toast.makeText(Michael_video.this, getResources().getString(R.string.done), Toast.LENGTH_SHORT).show();
								}
						 }});
					}
			}
		}
		catch(Exception e)
		{
			
		}
	}
	
	public void det_button(View view)
	{
		Button tv = (Button)findViewById(R.id.button1);
		if(tv.getText().toString().equalsIgnoreCase("pause"))
		{
			onPause(tv);
		}
		
		else if(tv.getText().toString().equalsIgnoreCase("resume"))
		{
			onResume(tv);
		}
	}
	
	public void onPause(Button tv)
	{
		 videoView.pause();
		 tv.setText(getResources().getString(R.string.Resume));
	}
	
	public void onResume(Button tv)
	{
		videoView.start();
		tv.setText(getResources().getString(R.string.pause));
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// Handle action bar item clicks here. The action bar will
		// automatically handle clicks on the Home/Up button, so long
		// as you specify a parent activity in AndroidManifest.xml.
		int id = item.getItemId();
		if (id == R.id.action_settings) {
			return true;
		}
		return super.onOptionsItemSelected(item);
	}
}
