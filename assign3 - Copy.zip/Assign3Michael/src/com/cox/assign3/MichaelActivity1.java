package com.cox.assign3;

import java.util.List;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.ActivityManager;
import android.app.ActivityManager.RunningTaskInfo;
import android.app.AlertDialog;
import android.content.ComponentName;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;


public class MichaelActivity1 extends Activity {

	RadioGroup rg;
	RadioButton rb;
    protected void onCreate(Bundle savedInstanceState) 
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cox1);
    }
    
    public String getRadioButton()
    {
    	rg = (RadioGroup)findViewById(R.id.radioGroup1);
    	rb = (RadioButton)findViewById(rg.getCheckedRadioButtonId());
    	return rb.getText().toString();
    }
    
  //  protected void onPause()
   // {
   // 	super.onPause();
    	
    //	  if (!this.isFinishing())
    //	  {
    	     //  Toast.makeText(MichaelActivity1.this, "home button clicked", Toast.LENGTH_SHORT).show();
    	       /*
    	       AlertDialog.Builder builder = new AlertDialog.Builder(MichaelActivity1.this);
    		    builder.setTitle(R.string.close_msg);
    			builder.setPositiveButton(R.string.close, new DialogInterface.OnClickListener() {
    			
    				public void onClick(DialogInterface dialog, int id){
    					
    			}});
    			
    		    
    			builder.setNegativeButton(R.string.cancel, new DialogInterface.OnClickListener(){
    				public void onClick(DialogInterface dialog, int id){}}).show();
    	       
    	       */
    	//  }   	
    	/*
    	AlertDialog.Builder builder = new AlertDialog.Builder(MichaelActivity1.this);
	    builder.setTitle(R.string.close_msg);
		builder.setPositiveButton(R.string.close, new DialogInterface.OnClickListener() {
		
			public void onClick(DialogInterface dialog, int id){
				
		}});
		
	    
		builder.setNegativeButton(R.string.cancel, new DialogInterface.OnClickListener(){
			public void onClick(DialogInterface dialog, int id){}}).show();
		*/
	 // 	 super.onStop();
	
    
/*
public boolean isApplicationSentToBackground(final Context context) {
    ActivityManager am = (ActivityManager) context.getSystemService(Context.ACTIVITY_SERVICE);
    List<RunningTaskInfo> tasks = am.getRunningTasks(1);
    if (!tasks.isEmpty()) {
        ComponentName topActivity = tasks.get(0).topActivity;
        if (!topActivity.getPackageName().equals(context.getPackageName())) {
            return true;
        }
    }
    return false;
}
*/
    
	public boolean onKeyDown(int keyCode, KeyEvent event) {
	if ((keyCode == KeyEvent.KEYCODE_BACK)) {
	 		
		AlertDialog.Builder builder = new AlertDialog.Builder(MichaelActivity1.this);
	    builder.setTitle(R.string.close_msg);
		builder.setPositiveButton(R.string.ok, new DialogInterface.OnClickListener() {
		
			public void onClick(DialogInterface dialog, int id){
			System.exit(0);			
		}});
		builder.setNegativeButton(R.string.cancel, new DialogInterface.OnClickListener(){
			public void onClick(DialogInterface dialog, int id){}}).show();
	}
	
	return super.onKeyDown(keyCode, event);
	}	
	
    
    public void switch_screens(View view)
    {
    	try
    	{
	    	if(getRadioButton().equalsIgnoreCase("Download Activity"))
	    	{
	    		Intent i = new Intent(MichaelActivity1.this,Michael_download.class);
	    		startActivity(i);
	    	}
	    	if(getRadioButton().equalsIgnoreCase("Video Activity"))
	    	{
	    		Intent i = new Intent(MichaelActivity1.this,Michael_video.class);
	            startActivity(i);
	    	}
	    	if(getRadioButton().equalsIgnoreCase("SMS Activity"))
	    	{
	    		Intent i = new Intent(MichaelActivity1.this,Michael_sms.class);
	    		startActivity(i);
	    	}
	    	if(getRadioButton().equalsIgnoreCase("Gallery Activity"))
	    	{
	    		Intent i = new Intent(MichaelActivity1.this,Michael_gallery.class);
	    		startActivity(i);
	    	}
    	}catch(Exception e)
    	 {
    		AlertDialog.Builder builder = new AlertDialog.Builder(MichaelActivity1.this);
    	    builder.setTitle(R.string.click);
    		builder.setPositiveButton(R.string.ok, new DialogInterface.OnClickListener() {
    		public void onClick(DialogInterface dialog, int id){}}).show();
    	 }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();
        if (id == R.id.action_settings) {
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
}
