package com.cox.assign3;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.InputStream;
import java.io.InputStreamReader;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Environment;
import android.util.Log;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemSelectedListener;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

public class Michael_download extends Activity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.download_cox1);
		display_to_spinner();
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.michael_download, menu);
		return true;
	}
	
	
	public void display_to_spinner()
	{
		final Spinner spinner = (Spinner) findViewById(R.id.spinner1);
		
		String path = "/recipe";
		File sdCardRoot = Environment.getExternalStorageDirectory();
		File yourDir = new File(sdCardRoot, path);
		
		ArrayAdapter<String> file_names = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_dropdown_item);
		file_names.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
		 
		
		if(yourDir.listFiles().length == 0)
		{
			file_names.add(getResources().getString(R.string.name)+" No Files");
		}
		else
		{
			for(File file: yourDir.listFiles())
			{
				file_names.add(file.getName().toString().replace(".txt", ""));
			}
		}			
		spinner.setAdapter(file_names);
		
	    
	    spinner.setOnItemSelectedListener(new OnItemSelectedListener() {

			@Override
			public void onItemSelected(AdapterView<?> arg0, View arg1,int arg2, long arg3)
			{
			    final String selected = spinner.getSelectedItem().toString();
			   			   			    
			   runOnUiThread(new Runnable(){
					@Override
					public void run()
					{
						 read_file_display(selected);
					}
				   });					    
			}
			@Override
			public void onNothingSelected(AdapterView<?> arg0) {
				// TODO Auto-generated method stub				
			}	
	    });
	}
	
	
	public void read_file_display(String file_name)
	{
		 String line,line1 = "";
		 StringBuilder sb = new StringBuilder();
		try
		{
		    File root = Environment.getExternalStorageDirectory();
		    //String path = root.getAbsolutePath().toString()+""+file_name;
		    File file = new File(root,"/recipe/"+file_name+".txt");

		    BufferedReader br = new BufferedReader(new FileReader(file));
		    
		    while((line = br.readLine())!= null)
		    {
		       	sb.append(line+"\n");
		    }
		}
			catch (Exception e)
			{
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	      TextView tv = (TextView)findViewById(R.id.textView2);
	      tv.setText(sb.toString());
 	}
	
	public void back_to_main(View view)
	{
		Intent i = new Intent(Michael_download.this,MichaelActivity1.class);
		startActivity(i);
	}
	@Override
	public boolean onOptionsItemSelected(MenuItem item) 
	{
		// Handle action bar item clicks here. The action bar will
		// automatically handle clicks on the Home/Up button, so long
		// as you specify a parent activity in AndroidManifest.xml.
		int id = item.getItemId();
		if (id == R.id.action_settings) {
			return true;
		}
		return super.onOptionsItemSelected(item);
	}
}
