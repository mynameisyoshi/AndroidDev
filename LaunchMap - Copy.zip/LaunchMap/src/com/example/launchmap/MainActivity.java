package com.example.launchmap;

import android.os.Bundle;
import android.app.Activity;
import android.content.Intent;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.Toast;

public class MainActivity extends Activity {
Button secondScreen;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        
        secondScreen = (Button) findViewById(R.id.button1);
        secondScreen.setBackgroundColor(getResources().getColor(R.color.light_blue));
        
        try {
        	secondScreen.setOnClickListener(new View.OnClickListener() {
				public void onClick(View arg0) {
					LaunchSecondScreen();
				}
			});
		} catch (Exception e) {
			Toast.makeText(getApplicationContext(), "Error: " + e,
					Toast.LENGTH_LONG);
		}
    }

    public void LaunchSecondScreen(){
    	Intent i = new Intent(getApplicationContext(),
				SecondActivity.class);
		startActivity(i);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }
    
}
