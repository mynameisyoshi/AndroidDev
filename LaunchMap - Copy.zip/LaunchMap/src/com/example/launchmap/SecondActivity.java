package com.example.launchmap;

import android.net.Uri;
import android.os.Bundle;
import android.app.Activity;
import android.content.Intent;
import android.view.Menu;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class SecondActivity extends Activity {

	Button launchMap;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_second);
		
		launchMap = (Button) findViewById(R.id.button1);
		launchMap.setBackgroundColor(getResources().getColor(R.color.light_green));
		
		
        
        try {
        	launchMap.setOnClickListener(new View.OnClickListener() {
				public void onClick(View arg0) {
					LaunchMap();
				}
			});
		} catch (Exception e) {
			Toast.makeText(getApplicationContext(), "Error: " + e,
					Toast.LENGTH_LONG);
		}
	}

	public void LaunchMap(){
		try
		{
			Intent intent = new Intent(android.content.Intent.ACTION_VIEW, 
					Uri.parse("http://maps.google.com/maps?saddr=43.67023,-79.38676&daddr=45.42349,-75.69793"));
					startActivity(intent);
		}
		catch (Exception e) {
			Toast.makeText(getApplicationContext(), "Error: " + e,
					Toast.LENGTH_LONG);
		}
	}
	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.second, menu);
		return true;
	}

}
