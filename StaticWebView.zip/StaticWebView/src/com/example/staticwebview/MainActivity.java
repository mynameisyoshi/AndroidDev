package com.example.staticwebview;

import android.os.Bundle;
import android.app.Activity;
import android.view.Menu;
import android.webkit.WebView;

public class MainActivity extends Activity {
	 private WebView webView;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		
		setContentView(R.layout.activity_main);
        webView = (WebView) findViewById(R.id.webView);
                String customHtml = "<html><body><h1>Hello, WebView</h1>" +
                               "<h1>Heading 1</h1><p>This is a sample paragraph.</p>" +
                               "</body></html>";
        webView.loadData(customHtml, "text/html", "UTF-8");
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}

}
