package com.pocket.chef;


import java.util.ArrayList;
import java.util.concurrent.ExecutionException;
import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.AdapterView.OnItemClickListener;

public class SearchFragment extends Fragment {
	Bundle b;	
	ArrayList<Recipes> recipesL = null;
	ListView list;
	Context context;
	
	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		
		View v = inflater.inflate(R.layout.fragment_search, container, false);
		list = (ListView) v.findViewById(R.id.searchlist);

		
		if(!isNetworkAvailable()){
			View rootView = inflater.inflate(R.layout.empty_list_item, container, false);
			list.setEmptyView(rootView);
			return rootView;
		}
		else{
		
			final View rootView = inflater.inflate(R.layout.fragment_search, container, false);
			final EditText eText = (EditText) rootView.findViewById(R.id.editText1);
			
			String dinnerRssFeed = getResources().getString(R.string.dinnerRssFeed);
			String dinnerRssFeed2 = "http://feeds.epicurious.com/healthy_recipes";
			String lunchRssFeed = getResources().getString(R.string.lunchRssFeed);
			String breakfastRssFeed = getResources().getString(R.string.breakfastRssFeed);
			list = (ListView) rootView.findViewById(R.id.searchlist);
	
			b = getActivity().getIntent().getExtras();
			
			try {
				switch(Integer.parseInt(b.getString("catSelected"))){
				case 1:
					recipesL = new RssFeed().execute(breakfastRssFeed).get();
					break;
				case 2:
					recipesL = new RssFeed().execute(lunchRssFeed).get();
					break;
				case 3:
					recipesL = new RssFeed().execute(dinnerRssFeed).get();
					recipesL.addAll(new RssFeed().execute(dinnerRssFeed2).get()) ;
					break;
				}
					
				ArrayAdapt adapt = new ArrayAdapt(rootView.getContext(),R.layout.customlist, recipesL);
				
				list.setAdapter(adapt);
				adapt.notifyDataSetChanged();
				
			    list.setOnItemClickListener(new OnItemClickListener() {
			        public void onItemClick(AdapterView<?> parent, View v, int position, long id) {
			           
			        	//Bundle b = new Bundle();
			        	Recipes tempR = (Recipes) list.getItemAtPosition(position);
			        	
			        	String selectedFromList =(String) (tempR.getLink());
			        	b.putString("selectedContentFromSearch", selectedFromList);
			        	b.putString("selectedFromList", tempR.getTitle());
			        	
			        	Intent i = new Intent(getActivity(),ViewRecipeActivity.class);
			        	i.putExtras(b);
			    		startActivity(i);
			        		
			        }
			    });
			    
			    eText.addTextChangedListener(new TextWatcher(){
	
					@Override
					public void beforeTextChanged(CharSequence s, int start,
							int count, int after) {
						// TODO Auto-generated method stub
						
					}
	
					@Override
					public void onTextChanged(CharSequence s, int start,
							int before, int count) {
						// TODO Auto-generated method stub
						ArrayList<Recipes> temp = new ArrayList<Recipes>();
						ArrayAdapter adapter = new ArrayAdapt(rootView.getContext(),R.layout.customlist, temp);
						int textlength = eText.getText().length();
						temp.clear();
						for(int i = 0; i < recipesL.size(); i++){
							if(textlength <= recipesL.get(i).title.length())
							{
								if(eText.getText().toString().equalsIgnoreCase((String)recipesL.get(i).title.subSequence(0, textlength))){
									temp.add(recipesL.get(i));
								}
								
							}
						}
						list.setAdapter(adapter);
					}
	
					@Override
					public void afterTextChanged(Editable s) {
						// TODO Auto-generated method stub
						
					}
			    	
			    });
				    
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (ExecutionException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			return rootView;
		}
		
	}

	public boolean isNetworkAvailable()  // determines if the network is available or not
	{
	    ConnectivityManager connectivityManager = (ConnectivityManager)
	    		getActivity().getSystemService(Context.CONNECTIVITY_SERVICE);
	    
	    NetworkInfo activeNetworkInfo = connectivityManager.getActiveNetworkInfo();
	    
	    return activeNetworkInfo != null && activeNetworkInfo.isConnected();  //return true if network is available| false if not available
	}
	
}
