package com.pocket.chef;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.AssetManager;
import android.database.SQLException;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Environment;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.PopupMenu;

public class HomeActivity extends Activity {

	private MySQLiteHelper mydb;
	SharedPreferences prefs = null;
	
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setTheme(R.style.AppTheme);
        setContentView(R.layout.activity_home);

        prefs = getSharedPreferences(getString(R.string.package_name), MODE_PRIVATE);
        mydb = new MySQLiteHelper(this);
        
        
        
        //create and inserts initial tables with values on first run
        if (prefs.getBoolean("firstrun", true)) {
        	Log.d("running first time","running first time");
        	
	    	//CopyFiles cf = new CopyFiles();
	    	String[] initRecipes = {getResources().getString(R.string.old_fashioned_pancakes),getResources().getString(R.string.salisbury_steak_with_mushroom_gravy),getResources().getString(R.string.caramelized_chicken_wings)};
	    	Log.d("in string[]",initRecipes[0]);

        	File file_system = Environment.getExternalStorageDirectory();
	    	File dir = new File (file_system.getAbsolutePath() + "/Recipes");
	    	Log.d("dir",file_system.getAbsolutePath()+ "/Recipes");
	    	dir.mkdirs();
	    	
        	copyAssets(initRecipes);
        	
	        try {
	        	mydb.createdb();
	        	mydb.openDataBaseWrite();
	        	mydb.insertInitialTables();
	            mydb.insertNewRecipe(this.getString(R.string.old_fashioned_pancakes),this.getString(R.string.old_fashioned_pancakes_c),1);
	            mydb.insertNewRecipe(this.getString(R.string.caramelized_chicken_wings),this.getString(R.string.caramelized_chicken_wings_c),2);
	            mydb.insertNewRecipe(this.getString(R.string.salisbury_steak_with_mushroom_gravy),this.getString(R.string.salisbury_steak_with_mushroom_gravy_c),3);
	            mydb.closedb();
	    	}catch(SQLException sqle){throw sqle;}   
	        prefs.edit().putBoolean("firstrun", false).commit();
        }
    }

    String theme = " ";
    
    public void menu(View view)
    {
    	Button button = (Button)findViewById(R.id.settingB);
    	
    	PopupMenu popup = new PopupMenu(HomeActivity.this, button);
        //Inflating the Popup using xml file
        popup.getMenuInflater().inflate(R.menu.menu, popup.getMenu());

        //registering popup with OnMenuItemClickListener
        popup.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
        	
         public boolean onMenuItemClick(MenuItem item) {  
        	 String theme_selected = item.getTitle().toString(); //gets the theme selected
        	 View v = findViewById(R.id.homelayout);
        	
        	 if (theme_selected.equalsIgnoreCase("Black"))
             {        	               
                 Button button = (Button)findViewById(R.id.startB);
                 button.setBackgroundColor(Color.rgb(0, 0, 0));
                 v.setBackground(getResources().getDrawable(R.drawable.homebgblack));
           	  setTheme(R.style.Theme4);

           	  theme = "Black";
             }
        
          if (theme_selected.equalsIgnoreCase("Red"))
          {        	                 
              Button button = (Button)findViewById(R.id.startB);
              button.setBackgroundColor(Color.rgb(255, 102, 102));
              v.setBackground(getResources().getDrawable(R.drawable.homebgred));
        	  
              setTheme(R.style.Theme1);
             
        	  theme = "Red";
          }
          
          if(theme_selected.equalsIgnoreCase("Blue"))
          {        	   
              Button button = (Button)findViewById(R.id.startB);
              button.setBackgroundColor(Color.rgb(0, 0, 153));
              v.setBackground(getResources().getDrawable(R.drawable.homebgblue));
        	  setTheme(R.style.Theme2);

              theme = "Blue";
          }
          if(theme_selected.equalsIgnoreCase("Gray"))
          {        	    
              Button button = (Button)findViewById(R.id.startB);
              button.setBackgroundColor(Color.rgb(128, 128, 128));
              v.setBackground(getResources().getDrawable(R.drawable.homebggrey));
        	  setTheme(R.style.Theme3);

              theme = "Gray";
          }
          return true;
         }
        });
        popup.show();//showing popup menu
       }
    
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.home, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();
        if (id == R.id.action_settings) {
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
    
    //starts categories activity
    public void startCategoriesAct(View v){
    	Intent i = new Intent(this,CategoriesActivity.class);
    	i.putExtra("theme", theme);
    	startActivity(i);
    }//end of startCategories
    
    
    public void copyAssets(String[] fileList) {
	    AssetManager assetManager = getAssets();
	    String[] files = fileList;
	    try {
	        files = assetManager.list("Recipes");
	    } catch (IOException e) {
	        Log.e("tag", "Failed to get asset file list.", e);
	    }
	    
	    for(String filename : files) {
	    	Log.d("file in assets",filename);
	    }
	    
	    for(String filename : files) {
	    	Log.d("file in assets",filename);

	        InputStream in = null;
	        OutputStream out = null;
	        try {
	          in = assetManager.open("Recipes/"+filename);
	          File outFile = new File( Environment.getExternalStorageDirectory().getAbsolutePath() + "/Recipes/" + filename);
	          out = new FileOutputStream(outFile);
	          copyFile(in, out);
	        } catch(IOException e) {
	            Log.e("tag", "Failed to copy asset file: " + filename, e);
	        }     
	        finally {
	            if (in != null) {
	                try {
	                    in.close();
	                } catch (IOException e) {
	                    // NOOP
	                }
	            }
	            if (out != null) {
	                try {
	                    out.close();
	                } catch (IOException e) {
	                    // NOOP
	                }
	            }
	        }  
	    }
	}
	private void copyFile(InputStream in, OutputStream out) throws IOException {
	    byte[] buffer = new byte[1024];
	    int read;
	    while((read = in.read(buffer)) != -1){
	      out.write(buffer, 0, read);
	    }
	}
    
	
}
