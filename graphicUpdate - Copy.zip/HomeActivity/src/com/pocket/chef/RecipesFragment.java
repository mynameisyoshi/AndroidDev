package com.pocket.chef;

import java.util.ArrayList;
import android.content.Context;
import android.content.Intent;
import android.database.SQLException;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.AdapterView.OnItemClickListener;


public class RecipesFragment extends Fragment {

	private MySQLiteHelper db;
	ArrayAdapter<String> adapter=null;
	ArrayList<String> recipesAL;
	int catSelected;
	ListView recipeList;
	Context context;
	Bundle b;
	
	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {

		b = getActivity().getIntent().getExtras();
				
		View rootView = inflater.inflate(R.layout.fragment_recipes, container, false);
		
		db = new MySQLiteHelper(context);
		recipeList = (ListView) rootView.findViewById(R.id.mylist);
		
		try {
			db.openDataBaseRead();
			recipesAL = db.getRecipeName(b.getString("catSelected"));
		}catch(SQLException sqle){
			sqle.printStackTrace();}
		finally{db.closedb();}
		
		if(recipesAL.isEmpty()){
			rootView = inflater.inflate(R.layout.empty_list_item, container, false);
			recipeList.setEmptyView(rootView);
		}
		else{
			
			adapter = new ArrayAdapter<String> (this.getActivity(),android.R.layout.simple_list_item_1,recipesAL);
			recipeList.setAdapter(adapter);
		    adapter.notifyDataSetChanged();
		    recipeList.setOnItemClickListener(new OnItemClickListener() {
		        public void onItemClick(AdapterView<?> parent, View v, int position, long id) {
		           
		        	//Bundle b = new Bundle();
		        	
		        	String selectedFromList =(String) (recipeList.getItemAtPosition(position));
		        	b.putString("selectedFromList", selectedFromList);
		        	
		        	Intent i = new Intent(getActivity(),ViewRecipeActivity.class);
		        	i.putExtras(b);
		    		startActivity(i);
		        		
		        }
		    });
		}
		return rootView;
	}


}

