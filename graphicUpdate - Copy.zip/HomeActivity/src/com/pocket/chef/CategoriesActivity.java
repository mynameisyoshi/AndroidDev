package com.pocket.chef;

import android.app.ActionBar;
import android.app.Activity;
import android.content.Intent;
import android.database.SQLException;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;

public class CategoriesActivity extends Activity implements ActionBar.OnNavigationListener {

	int catSelected; //category selected
	private ActionBar actionBar ;
	Button breakfastB,lunchB,dinnerB;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_categories);
		
		gettheme();
		
		//gets the views
		breakfastB = (Button)findViewById(R.id.breakfastB);
		lunchB = (Button)findViewById(R.id.lunchB);
		dinnerB = (Button)findViewById(R.id.dinnerB);
		
		//sets what category is selected to be passed to next activity
		breakfastB.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				catSelected = 1;//breakfast category
				startTabsAct(v);
			}
			
		});
		
		lunchB.setOnClickListener(new View.OnClickListener() {

			@Override
			public void onClick(View v) {
				catSelected = 2;//lunch category
				startTabsAct(v);
			}
			
		});
		
		dinnerB.setOnClickListener(new View.OnClickListener() {

			@Override
			public void onClick(View v) {
				catSelected = 3;//dinner category
				startTabsAct(v);
			}
			
		});
		
		actionBar = getActionBar();
		actionBar.show();
		actionBar.setDisplayShowTitleEnabled(false);
		actionBar.setHomeButtonEnabled(true);
		
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.categories, menu);
		return true;
	}
	
	// displays a theme that the last activity is displaying
	public void gettheme()
	{
		Bundle i = getIntent().getExtras();
		breakfastB = (Button)findViewById(R.id.breakfastB);
		lunchB = (Button)findViewById(R.id.lunchB);
		dinnerB = (Button)findViewById(R.id.dinnerB);
		
		String msg = i.getString("theme");
		if(msg.equalsIgnoreCase("Black"))
		{
			 ActionBar ab = getActionBar();
             ab.setBackgroundDrawable(new ColorDrawable(Color.rgb(0, 0, 0)));
             breakfastB.getResources().getDrawable(R.drawable.catbreakfastb);
             lunchB.getResources().getDrawable(R.drawable.catlunchb);
             dinnerB.getResources().getDrawable(R.drawable.catdinnerb);
		}
		if(msg.equalsIgnoreCase("Red"))
		{
			 ActionBar ab = getActionBar();
             ab.setBackgroundDrawable(new ColorDrawable(Color.rgb(255, 102, 102)));
             breakfastB.getResources().getDrawable(R.drawable.catbreakfastr);
             lunchB.getResources().getDrawable(R.drawable.catlunchr);
             dinnerB.getResources().getDrawable(R.drawable.catdinnerr);
		}
		if(msg.equalsIgnoreCase("Gray"))
		{
			 ActionBar ab = getActionBar();
             ab.setBackgroundDrawable(new ColorDrawable(Color.rgb(128, 128, 128)));
             breakfastB.getResources().getDrawable(R.drawable.catbreakfastg);
             lunchB.getResources().getDrawable(R.drawable.catlunchg);
             dinnerB.getResources().getDrawable(R.drawable.catdinnerg);
		}
		if(msg.equalsIgnoreCase("Blue"))
		{
			 ActionBar ab = getActionBar();
             ab.setBackgroundDrawable(new ColorDrawable(Color.rgb(0, 0, 153)));
             breakfastB.getResources().getDrawable(R.drawable.catbreakfastbl);
             lunchB.getResources().getDrawable(R.drawable.catlunchbl);
             dinnerB.getResources().getDrawable(R.drawable.catdinnerbl);
		}
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// Handle action bar item clicks here. The action bar will
		// automatically handle clicks on the Home/Up button, so long
		// as you specify a parent activity in AndroidManifest.xml.
		int id = item.getItemId();
		if (id == R.id.action_settings) {
			return true;
		}
		
		switch (item.getItemId()) {			
		case android.R.id.home:
			back();
			return true;
		default:
			return super.onOptionsItemSelected(item);
		}
	}
	
	//starts Tabs Activity. Sets data that the next activity needs
	public void startTabsAct(View v){
		Intent i = new Intent(this,TabsActivity.class);
        Bundle b = getIntent().getExtras();
        b.putString("catSelected", Integer.toString(catSelected));
        
		String msg = b.getString("theme");
		
		Log.d("catSel",Integer.toString(catSelected));
		
		i.putExtra("theme", msg);
		i.putExtras(b);
		startActivity(i);
	}//end of startTabsAct

	@Override
	public boolean onNavigationItemSelected(int itemPosition, long itemId) {
		// TODO Auto-generated method stub
		return false;
	}
	
	public void back(){
		Intent i = new Intent(this,HomeActivity.class);
		//i.putExtras(b);
		startActivity(i);
	}
}//end of class
