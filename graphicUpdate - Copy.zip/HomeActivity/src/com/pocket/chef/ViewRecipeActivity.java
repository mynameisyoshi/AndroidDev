package com.pocket.chef;

import android.app.ActionBar;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.SQLException;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.os.Environment;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

public class ViewRecipeActivity extends Activity implements ActionBar.OnNavigationListener  {

	Bundle b;
	String recipeContent,selectedContentFromSearch,selectedNameFromSearch;
	String recipeName;
	String recipeCat;
	private ActionBar actionBar;
	private MySQLiteHelper db;
	private WebView recipeWV;
		
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_view_recipe);
		
		gettheme();
		
		db = new MySQLiteHelper(this);
		b = getIntent().getExtras();
		recipeCat = b.getString("catSelected");
		
		recipeWV = (WebView)findViewById(R.id.recipeWebView);
		
		if(b.containsKey("selectedContentFromSearch")){
			selectedContentFromSearch=b.getString("selectedContentFromSearch");
		}
		
		if(b.containsKey("selectedFromList")){
			selectedNameFromSearch=b.getString("selectedFromList");
		}
		
		if(b.containsKey("selectedFromList")){
			recipeName=b.getString("selectedFromList");
		}
		
		try {
			db.openDataBaseRead();
			recipeContent = db.getRecipeContent(recipeName);
		}catch(SQLException sqle){throw sqle;}
		finally{db.closedb();}
		
		if(recipeContent == null){
			recipeContent = selectedContentFromSearch;
			recipeName = selectedNameFromSearch;
		}
		
		actionBar = getActionBar();
		actionBar.setDisplayShowTitleEnabled(false);
		actionBar.setHomeButtonEnabled(true);
		if(isNetworkAvailable()){		
			viewFromWeb();
		}
		else viewFromLocal();
		
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.view_act_tabs_action, menu);

		
		try{
			db.openDataBaseRead();
			if(db.checkFavourite(recipeName)){
				menu.getItem(0).setIcon(getResources().getDrawable(R.drawable.ic_menu_star_fav));
			}
			else{
				menu.getItem(0).setIcon(getResources().getDrawable(R.drawable.ic_menu_star));
			}
		}catch(SQLException e){e.printStackTrace();}
		finally{db.closedb();}
		
		try{
			db.openDataBaseRead();
			if(db.checkIfExists(recipeName)){
				menu.getItem(1).setIcon(getResources().getDrawable(R.drawable.ic_menu_saved));			
			}
			else{
				menu.getItem(1).setIcon(getResources().getDrawable(R.drawable.ic_menu_save));			
			}
		}catch(SQLException e){e.printStackTrace();}
		finally{db.closedb();}

		
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// Handle action bar item clicks here. The action bar will
		// automatically handle clicks on the Home/Up button, so long
		// as you specify a parent activity in AndroidManifest.xml.
		int id = item.getItemId();
		if (id == R.id.action_settings) {
			return true;
		}
		
		//changes icon state
		switch (item.getItemId()) {
		case R.id.action_favourite:		
			try{
				db.openDataBaseRead();
				if(!db.checkFavourite(recipeName)){
					if(db.checkIfExists(recipeName)){
						setAsFavourite();
						item.setIcon(R.drawable.ic_menu_star_fav);
					}
					else{
						new AlertDialog.Builder(this)
					    .setTitle(R.string.unable)
					    .setMessage(R.string.please_save)
					    .setPositiveButton(android.R.string.ok, new DialogInterface.OnClickListener() {
					        public void onClick(DialogInterface dialog, int which) { 
					            
					        }
					     })
					    
					    .setIcon(android.R.drawable.ic_dialog_alert)
					     .show();
					}
				}
				else if (db.checkFavourite(recipeName)){
					removeAsFavourite();
					item.setIcon(R.drawable.ic_menu_star);
				}
			}catch(SQLException e){e.printStackTrace();}
			finally{db.closedb();}

			return true;
		case R.id.action_save:
			try{
				db.openDataBaseRead();
				if(!db.checkIfExists(recipeName)){
					db.closedb();
					save();
					item.setIcon(R.drawable.ic_menu_saved);
				}
			}catch(SQLException e){e.printStackTrace();}
			finally{db.closedb();}

			return true;
		case android.R.id.home:
			back();
			return true;
		default:
			return super.onOptionsItemSelected(item);
		}
	}

	@Override
	public boolean onNavigationItemSelected(int arg0, long arg1) {
		// TODO Auto-generated method stub
		return false;
	}
	
	// displays a theme that the last activity is displaying
	public void gettheme()
		{
			Bundle i = getIntent().getExtras();
			
			String msg = i.getString("theme");
			if(msg.equalsIgnoreCase("Black"))
			{
				 ActionBar ab = getActionBar();
	             ab.setBackgroundDrawable(new ColorDrawable(Color.rgb(0, 0, 0)));
			}
			if(msg.equalsIgnoreCase("Red"))
			{
				 ActionBar ab = getActionBar();
	             ab.setBackgroundDrawable(new ColorDrawable(Color.rgb(255, 102, 102)));
			}
			if(msg.equalsIgnoreCase("Gray"))
			{
				 ActionBar ab = getActionBar();
	             ab.setBackgroundDrawable(new ColorDrawable(Color.rgb(128, 128, 128)));
	             
			}
			if(msg.equalsIgnoreCase("Blue"))
			{
				 ActionBar ab = getActionBar();
	             ab.setBackgroundDrawable(new ColorDrawable(Color.rgb(0, 0, 153)));
	             
			}
		}
	
	public void viewFromWeb(){
		WebSettings ws = recipeWV.getSettings();
		ws.setSupportZoom(true);
		ws.setBuiltInZoomControls(true);
				 
		recipeWV.setWebViewClient(new WebViewClient());
		recipeWV.clearCache(true);
		recipeWV.loadUrl(recipeContent);
	}
	
	public void viewFromLocal(){
		WebSettings ws = recipeWV.getSettings();
		ws.setSupportZoom(true);
		ws.setBuiltInZoomControls(true);
				 
		recipeWV.setWebViewClient(new WebViewClient());
		recipeWV.clearCache(true);
		recipeWV.loadUrl("file:"+Environment.getExternalStorageDirectory().getAbsolutePath()+ "/Recipes/"+recipeName+".html");
	}
	
	public void setAsFavourite(){
	
		try{
			db.openDataBaseWrite();
			db.setAsFavourite(recipeName);
		}catch(SQLException e){e.printStackTrace();}
		finally{db.closedb();}

	}
	
	public void removeAsFavourite(){
		try{
			db.openDataBaseWrite();
			Log.d("removing favourite","setting "+recipeName+" as favourite");
			db.removeAsFavourite(recipeName);
		}catch(SQLException e){e.printStackTrace();}
		finally{db.closedb();}

	}
	
	public boolean isNetworkAvailable()  // determines if the network is available or not
	{
	    ConnectivityManager connectivityManager = (ConnectivityManager)
	    		getSystemService(Context.CONNECTIVITY_SERVICE);
	    
	    NetworkInfo activeNetworkInfo = connectivityManager.getActiveNetworkInfo();
	    
	    return activeNetworkInfo != null && activeNetworkInfo.isConnected();  //return true if network is available| false if not available
	}
	
	public void save(){
		
		HTMLextractor htmlExtractor = new HTMLextractor();
		htmlExtractor.extract_save_html(recipeContent,recipeName);
		
		try{
			db.openDataBaseWrite();
			db.insertNewRecipe(recipeName, recipeContent,Integer.parseInt(recipeCat));//removeAsFavourite(recipeName);
		}catch(SQLException e){e.printStackTrace();}
		finally{db.closedb();}

	}
	
	public void unSave(){
		try{
			db.openDataBaseWrite();
			db.removeRecipe(recipeName);
		}catch(SQLException e){e.printStackTrace();}
		finally{db.closedb();}
	}
	
	public void back(){
		Intent i = new Intent(this,TabsActivity.class);
		i.putExtras(b);
		startActivity(i);
	}

	
}
