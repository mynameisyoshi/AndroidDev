package com.example.playvideofilessdcard;


import android.media.MediaPlayer;
import android.media.MediaPlayer.OnCompletionListener;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore.Video;
import android.app.Activity;
import android.database.Cursor;
import android.view.KeyEvent;
import android.view.Menu;
import android.widget.MediaController;
import android.widget.Toast;
import android.widget.VideoView;

public class MainActivity extends Activity implements OnCompletionListener{
	Cursor mediaCursor=null;
	 VideoView videoView=null;
	 int dataIdx=0;
	 
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		
		videoView = (VideoView)findViewById(R.id.myvideoview);
		try
		{
		videoView.setOnCompletionListener((OnCompletionListener) this);
	    String projection[]=new String[] {Video.Media.DATA};
	    
	    String videoPath = Environment.getExternalStorageDirectory()+"/Movies/Sample1.mp4";
	  
	    videoView.setVideoPath(videoPath);
	    videoView.setMediaController(new MediaController(this));
	    videoView.requestFocus();
	    videoView.start();
		}
		catch (Exception ex){
			String x = ex.toString();
			String b = x;
		}
	    /*
	    if(mediaCursor!=null&&mediaCursor.getCount()>0){
	           dataIdx=mediaCursor.getColumnIndex(Video.Media.DATA);
	           playNextVideo();
	    }
		 */
	}
	
	private void playNextVideo(){
		/*
        mediaCursor.moveToNext();
        if(mediaCursor.isAfterLast()){ 
            Toast.makeText(getApplicationContext(),"End of Line",Toast.LENGTH_LONG).show();
        }
        else{
                String path=mediaCursor.getString(dataIdx);
                Toast.makeText(getApplicationContext(),"playing: "+path, Toast.LENGTH_LONG).show();
                videoView.setVideoPath(path);
                videoView.start();
        }
        */
	}
	
	@Override
	public void onDestroy(){
	     if (mediaCursor!=null){
	         mediaCursor.close();
	     }
	}
	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}

	@Override
	public void onCompletion(MediaPlayer arg0) {
		// TODO Auto-generated method stub
		 playNextVideo(); 
	}
	
	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {
	    if (keyCode == KeyEvent.KEYCODE_BACK) {
	        // your code
	    	System.exit(RESULT_OK);
	    }

	    return super.onKeyDown(keyCode, event);
	}
}
