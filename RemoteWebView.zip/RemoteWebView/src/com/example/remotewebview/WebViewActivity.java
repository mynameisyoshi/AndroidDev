package com.example.remotewebview;

import android.os.Bundle;
import android.app.Activity;
import android.view.Menu;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

public class WebViewActivity extends Activity {

	private WebView webView;
	 
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_web);
 
		webView = (WebView) findViewById(R.id.webView1);
		
		 WebSettings ws = webView.getSettings();
		 ws.setSupportZoom(true);
		 ws.setBuiltInZoomControls(true);
				 
		webView.setWebViewClient(new Callback());
		webView.clearCache(true);
		webView.loadUrl("http://www.cbc.ca");
		
		
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.web, menu);
		return true;
	}

	private class Callback extends WebViewClient {
		@Override
		public boolean shouldOverrideUrlLoading(
		WebView view, String url) {
		return(false);
		}
	}
}

