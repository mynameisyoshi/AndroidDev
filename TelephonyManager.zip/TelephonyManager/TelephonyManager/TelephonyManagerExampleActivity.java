

import android.app.Activity;

import android.content.Context;
import android.os.Bundle;
import android.provider.SyncStateContract.Constants;
import android.telephony.PhoneStateListener;
import android.telephony.TelephonyManager;
//import android.telephony.gsm.GsmCellLocation;
import android.util.Log;
import android.widget.TextView;

public class TelephonyManagerExampleActivity extends Activity {
	private TextView telMgrOutput;
    /** Called when the activity is first created. */
	 @Override
	   public void onCreate(final Bundle icicle) {
	      Log.d(Constants.DATA, "TelephonyManagerExample onCreate");

	      super.onCreate(icicle);
	      this.setContentView(R.layout.main);

	      this.telMgrOutput = (TextView) this.findViewById(R.id.telmgroutput);
	   }
	 
	 @Override
	   public void onStart() {
	      super.onStart();
	      try
	      {
	      // TelephonyManager
	      final TelephonyManager telMgr = (TelephonyManager) this.getSystemService(Context.TELEPHONY_SERVICE);
	      this.telMgrOutput.setText(telMgr.toString());

	      // PhoneStateListener
	      PhoneStateListener phoneStateListener = new PhoneStateListener() {
	         @Override
	         public void onCallStateChanged(final int state, final String incomingNumber) {
	        	 TelephonyManagerExampleActivity.this.telMgrOutput
	                     .setText(TelephonyManagerExampleActivity.this.getTelephonyOverview(telMgr));
	            Log.d(Constants.DATA, "phoneState updated - incoming number - " + incomingNumber);
	         }
	      };
	      telMgr.listen(phoneStateListener, PhoneStateListener.LISTEN_CALL_STATE);

	      String telephonyOverview = this.getTelephonyOverview(telMgr);
	      this.telMgrOutput.setText(telephonyOverview);
	      }
	      catch(Exception ex){
	    	  System.out.println(ex.toString());
	    	  String x = "hello";
	      }
	   }

	 /**
	    * Parse TelephonyManager values into a human readable String.
	    *     
	    * @param telMgr
	    * @return
	    */
	   public String getTelephonyOverview(final TelephonyManager telMgr) {
		// TODO Auto-generated method stub
		   int callState = telMgr.getCallState();
		      String callStateString = "NA";
		      switch (callState) {
		      case TelephonyManager.CALL_STATE_IDLE:
		         callStateString = "IDLE";
		         break;
		      case TelephonyManager.CALL_STATE_OFFHOOK:
		         callStateString = "OFFHOOK";
		         break;
		      case TelephonyManager.CALL_STATE_RINGING:
		         callStateString = "RINGING";
		         break;
		      }
		      
		      StringBuilder sb = new StringBuilder();
		      sb.append("telMgr - ");
		      sb.append("  \ncallState = " + callStateString);

		      return sb.toString();      
	}
}