package com.net.sendsms;

import android.app.Activity;

import android.content.Intent;

import android.net.Uri;
import android.os.Bundle;


import android.view.Menu;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends Activity {
	    Button btnSendSMS;
	    EditText txtPhoneNo;
	    EditText txtMessage;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		
		btnSendSMS = (Button) findViewById(R.id.btnSendSMS);
        txtPhoneNo = (EditText) findViewById(R.id.txtPhoneNo);
        txtMessage = (EditText) findViewById(R.id.txtMessage);
 
        btnSendSMS.setOnClickListener(new View.OnClickListener() 
        {
            public void onClick(View v) 
            {                
                String phoneNo = txtPhoneNo.getText().toString();
                String message = txtMessage.getText().toString();                 
                if (phoneNo.length()>0 && message.length()>0)  
                	sendEmail(phoneNo, null, "Test Email Subject",message);                
                else
                    Toast.makeText(getBaseContext(), 
                        "Please enter both email and email body!.", 
                        Toast.LENGTH_LONG).show();
            }

			
        });   
        
        
	}

	private void sendEmail(String emailAddresses, String carbonCopies,
			String subject, String message)
			{
				try
				{
					Intent emailIntent = new Intent(Intent.ACTION_SEND);
					emailIntent.setData(Uri.parse("mailto:"));
					String to = emailAddresses;
					String cc = carbonCopies;
					emailIntent.putExtra(Intent.EXTRA_EMAIL, to);
					emailIntent.putExtra(Intent.EXTRA_CC, cc);
					emailIntent.putExtra(Intent.EXTRA_SUBJECT, subject);
					emailIntent.putExtra(Intent.EXTRA_TEXT, message);
					emailIntent.setType("message/rfc822");
					startActivity(Intent.createChooser(emailIntent, "Email"));
					
					Toast.makeText(getBaseContext(), 
	                        "Email was sent successfully.", 
	                        Toast.LENGTH_LONG).show();
				}
				catch (Exception ex){
					Toast.makeText(getBaseContext(), 
	                        "Email wasn't sent." + ex.toString(), 
	                        Toast.LENGTH_LONG).show();
				}
			}


	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}

	
}

