/** Automatically generated file. DO NOT MODIFY */
package com.example.framebyframe;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}