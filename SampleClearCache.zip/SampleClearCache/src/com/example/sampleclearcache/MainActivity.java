package com.example.sampleclearcache;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.OutputStreamWriter;

import android.app.Activity;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;

public class MainActivity extends Activity implements OnClickListener {
	/** Called when the activity is first created. */

	Button btnClearData;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		btnClearData = (Button) findViewById(R.id.buttonClearData);
		btnClearData.setOnClickListener(this);

		addUserDataInApplicationDir();
	}

	private void addUserDataInApplicationDir() {
		// Add shared preferences
		SharedPreferences settings = getSharedPreferences("sample", 0);
		SharedPreferences.Editor editor = settings.edit();
		editor.putBoolean("key1", true);
		editor.putString("key2", "Some strings in prefs");
		editor.commit();

		// Add file with content
		try {
			final String FILECONTENT = new String("This is string in file samplefile.txt");
			
			FileOutputStream fOut = openFileOutput("samplefile.txt", MODE_WORLD_READABLE);
			
			
			
			OutputStreamWriter osw = new OutputStreamWriter(fOut);
			osw.write(FILECONTENT);
			osw.flush();
			osw.close();

		} catch (IOException ioe) {
			ioe.printStackTrace();
		}
	}

	@Override
	public void onClick(View v) {
		
			//MyApplication.getInstance().clearApplicationData();
		clearApplicationData();
	}
	
	public void clearApplicationData() {
		File cache = getCacheDir();
		File appDir = new File(cache.getParent());
		if(appDir.exists()){
			String[] children = appDir.list();
			for(String s : children){
				String a = s;
				if(!s.equals("lib")){
					deleteDir(new File(appDir, s));
					Log.i("TAG", "**************** File /data/data/APP_PACKAGE/" + s +" DELETED *******************");
				}
			}
		}
	}
	
	public static boolean deleteDir(File dir) {
	    if (dir != null && dir.isDirectory()) {
	        String[] children = dir.list();
	        for (int i = 0; i < children.length; i++) {
	            boolean success = deleteDir(new File(dir, children[i]));
	            if (!success) {
	                return false;
	            }
	        }
	    }

	    return dir.delete();
	}
}